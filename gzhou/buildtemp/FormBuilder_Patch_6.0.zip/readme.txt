This installer will apply the Vitria OI Form Builder Patch 1.0 to your Vitria OI 6.0 installation.


Prerequisites:
To apply the Vitria OI Form Builder Patch 1.0, you must have an existing Vitria OI 6.0 installation.


Installation steps:
To apply the Vitria OI Form Builder Patch 1.0 to an existing Vitria OI 6.0 installation, follow the steps below:  
1. Get Vitria OI Form Builder Patch 1.0 zip file and unzip it. 
2. Stop JBoss for Vitria OI 6.0.
3. Make sure you have set the correct JAVA_HOME, VTBA_HOME, and JBOSS_HOME environment variables for your Vitria OI 6.0 installation.
4. After successfully unzipping the zip file, for Windows platforms, run install.bat. For Unix platforms, run install.sh.
5. Wait until the installation finishes, and check VTBA_HOME\logs\FormBuilderPatch-install.log to see if the installation completed successfully.


Uninstallation steps:
To remove the Vitria OI Form Builder Patch 1.0 from an existing Vitria OI 6.0 installation, follow the steps below:  
1. Stop JBoss for Vitria OI 6.0.
2. Make sure you have set the correct JAVA_HOME, VTBA_HOME, and JBOSS_HOME environment variables for your Vitria OI 6.0 installation.
3. Browse to VTBA_HOME\uninstall\Uninstall_FormBuilder.
   For Windows platforms, run uninstall.bat. For Unix platforms, run uninstall.sh.
4. Wait until the uninstallation finishes, and check VTBA_HOME\logs\FormBuilderPatch-uninstall.log to see if the uninstallation completed successfully.
