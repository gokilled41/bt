#!/bin/sh

# Copyright (c) 2007-2016 by Vitria Technology, Inc.
# All Rights Reserved.
#
# This SOURCE CODE FILE, which has been provided by Vitria as part
# of a Vitria product for use ONLY by licensed users of the product,
# includes information that is CONFIDENTIAL and PROPRIETARY to Vitria.
#
# ALL API's contained herein are for INTERNAL USE ONLY and are NOT to
# be used by ANY licensee of the product.  Vitria reserves the right
# to change such API's at any time and is not required to support
# them in current or future releases.
#
# USE OF THIS SOFTWARE IS GOVERNED BY THE TERMS AND CONDITIONS
# OF THE LICENSE STATEMENT AND LIMITED WARRANTY FURNISHED WITH
# THE PRODUCT.
#
# IN PARTICULAR, YOU WILL INDEMNIFY AND HOLD VITRIA HARMLESS FROM
# AND AGAINST ANY CLAIMS OR LIABILITIES ARISING OUT OF THE USE,
# REPRODUCTION, OR DISTRIBUTION OF YOUR PROGRAMS, INCLUDING ANY
# CLAIMS OR LIABILITIES ARISING OUT OF OR RESULTING FROM THE
# USE, MODIFICATION, OR DISTRIBUTION OF PROGRAMS OR FILES CREATED
# FROM, BASED ON, AND/OR/DERIVED FROM THIS SOURCE CODE FILE.


if [ -z "$VTBA_HOME" ]; then
    echo "The VTBA_HOME environment variable must be set before installing this product"
    exit 1
fi


ANT_Dir="$VTBA_HOME/ant/bin"
export ANT_Dir
if [ ! -f "$ANT_Dir/ant" ]; then
    echo "Cannot find ant in $ANT_Dir"
    exit 2
fi

if [ -z "$JAVA_HOME" ]; then
    echo "The JAVA_HOME environment variable must be set before installing this product"
    exit 3
fi

unset CLASSPATH
unset ANT_HOME

echo "The installer will apply the Vitria Form Builder Add-on Pack 1.0 to your Vtitria OI installation in $VTBA_HOME."
echo "Press 'y' to continue the installation, or press 'n' to exit, and then press Enter."
read USERINPUT
while [ "$USERINPUT" != "y" ]
do
  if [ "$USERINPUT" = "n" ]; then
    exit 4
  fi
  echo "Unknow option"
  echo "Press 'y' to continue the installation, and press 'n' to exit"
  read USERINPUT
done

# Define absolute path to installer directory
progDir=`dirname "$0"`
installerHome=`cd "$progDir" && pwd`

"$ANT_Dir/ant" --noconfig -f "$installerHome/stage/build.xml" -Dinstall.dir="$VTBA_HOME" -Dbackup.dir="$VTBA_HOME/uninstall/Uninstall_FormBuilder/backup"
